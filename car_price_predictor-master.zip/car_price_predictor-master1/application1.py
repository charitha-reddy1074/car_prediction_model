from flask import Flask, render_template, request
from flask_cors import CORS, cross_origin
from sklearn.linear_model import LinearRegression
import pandas as pd
import numpy as np

app = Flask(__name__)
CORS(app)

# Load the data
car = pd.read_csv('Cleaned_Car_data.csv')

# Check the columns in your DataFrame
print(car.columns)

# Assuming the correct column names are 'year' and 'kms_driven'
# Prepare the training data
X_train = car[['year', 'kms_driven']]  # Features
y_train = car['Price']  # Target

# Instantiate and train the model
model = LinearRegression()
model.fit(X_train, y_train)

@app.route('/', methods=['GET', 'POST'])

def index():
    companies = sorted(car['company'].unique())
    car_models = sorted(car['name'].unique())
    years = sorted(car['year'].unique(), reverse=True)
    fuel_types = car['fuel_type'].unique()

    companies.insert(0, 'Select Company')
    return render_template('index.html', companies=companies, car_models=car_models, years=years, fuel_types=fuel_types)

@app.route('/predict', methods=['POST'])
@cross_origin()
def predict():
    try:
        company = request.form.get('company')
        car_model = request.form.get('car_models')
        year = int(request.form.get('year'))
        fuel_type = request.form.get('fuel_type')
        driven = float(request.form.get('kilo_driven'))

        # Prepare input data for prediction
        input_data = np.array([[year, driven]])

        # Make prediction
        prediction = model.predict(input_data)
        predicted_price = np.round(prediction[0], 2)

        return render_template('result.html', prediction=predicted_price, company=company, car_model=car_model, year=year, fuel_type=fuel_type, driven=driven)

    except Exception as e:
        return str(e)  # Return the error message for debugging purposes

if __name__ == '__main__':
    app.run(debug=True)
